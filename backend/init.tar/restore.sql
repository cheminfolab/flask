--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4
-- Dumped by pg_dump version 14.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE userinterface_db;
--
-- Name: userinterface_db; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE userinterface_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'de_DE.UTF-8';


ALTER DATABASE userinterface_db OWNER TO admin;

\connect userinterface_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts_member; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_member (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    email character varying(254) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    is_staff boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    working_group_id bigint
);


ALTER TABLE public.accounts_member OWNER TO admin;

--
-- Name: accounts_member_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_member_groups (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.accounts_member_groups OWNER TO admin;

--
-- Name: accounts_member_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_member_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_member_groups_id_seq OWNER TO admin;

--
-- Name: accounts_member_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_member_groups_id_seq OWNED BY public.accounts_member_groups.id;


--
-- Name: accounts_member_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_member_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_member_id_seq OWNER TO admin;

--
-- Name: accounts_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_member_id_seq OWNED BY public.accounts_member.id;


--
-- Name: accounts_member_phones; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_member_phones (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    phonenumber_id bigint NOT NULL
);


ALTER TABLE public.accounts_member_phones OWNER TO admin;

--
-- Name: accounts_member_phones_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_member_phones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_member_phones_id_seq OWNER TO admin;

--
-- Name: accounts_member_phones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_member_phones_id_seq OWNED BY public.accounts_member_phones.id;


--
-- Name: accounts_member_role; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_member_role (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.accounts_member_role OWNER TO admin;

--
-- Name: accounts_member_role_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_member_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_member_role_id_seq OWNER TO admin;

--
-- Name: accounts_member_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_member_role_id_seq OWNED BY public.accounts_member_role.id;


--
-- Name: accounts_member_rooms; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_member_rooms (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    room_id integer NOT NULL
);


ALTER TABLE public.accounts_member_rooms OWNER TO admin;

--
-- Name: accounts_member_rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_member_rooms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_member_rooms_id_seq OWNER TO admin;

--
-- Name: accounts_member_rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_member_rooms_id_seq OWNED BY public.accounts_member_rooms.id;


--
-- Name: accounts_member_user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_member_user_permissions (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.accounts_member_user_permissions OWNER TO admin;

--
-- Name: accounts_member_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_member_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_member_user_permissions_id_seq OWNER TO admin;

--
-- Name: accounts_member_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_member_user_permissions_id_seq OWNED BY public.accounts_member_user_permissions.id;


--
-- Name: accounts_workinggroup; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_workinggroup (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    department character varying(200) NOT NULL,
    institution character varying(200) NOT NULL
);


ALTER TABLE public.accounts_workinggroup OWNER TO admin;

--
-- Name: accounts_workinggroup_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_workinggroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_workinggroup_id_seq OWNER TO admin;

--
-- Name: accounts_workinggroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_workinggroup_id_seq OWNED BY public.accounts_workinggroup.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: chemicals_category; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_category (
    id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.chemicals_category OWNER TO admin;

--
-- Name: chemicals_category_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_category_id_seq OWNER TO admin;

--
-- Name: chemicals_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_category_id_seq OWNED BY public.chemicals_category.id;


--
-- Name: chemicals_compound; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_compound (
    id bigint NOT NULL,
    pubchem_cid integer,
    purity double precision NOT NULL,
    density double precision,
    created date NOT NULL,
    created_by_id bigint,
    density_unit_id bigint,
    ghs_id bigint,
    substance_id bigint
);


ALTER TABLE public.chemicals_compound OWNER TO admin;

--
-- Name: chemicals_compound_category; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_compound_category (
    id bigint NOT NULL,
    compound_id bigint NOT NULL,
    category_id bigint NOT NULL
);


ALTER TABLE public.chemicals_compound_category OWNER TO admin;

--
-- Name: chemicals_compound_category_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_compound_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_compound_category_id_seq OWNER TO admin;

--
-- Name: chemicals_compound_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_compound_category_id_seq OWNED BY public.chemicals_compound_category.id;


--
-- Name: chemicals_compound_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_compound_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_compound_id_seq OWNER TO admin;

--
-- Name: chemicals_compound_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_compound_id_seq OWNED BY public.chemicals_compound.id;


--
-- Name: chemicals_container; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_container (
    id bigint NOT NULL,
    supplier character varying(250) NOT NULL,
    "EAN" character varying(13) NOT NULL,
    product_number character varying(100) NOT NULL,
    amount double precision,
    amount_left double precision,
    tara double precision,
    price numeric(10,2),
    description character varying(500) NOT NULL,
    conditions character varying(50) NOT NULL,
    opened date,
    last_used date,
    amount_unit_id bigint,
    compound_id bigint,
    currency_id bigint,
    last_user_id bigint,
    location_id bigint,
    owner_id bigint,
    tara_unit_id bigint
);


ALTER TABLE public.chemicals_container OWNER TO admin;

--
-- Name: chemicals_container_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_container_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_container_id_seq OWNER TO admin;

--
-- Name: chemicals_container_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_container_id_seq OWNED BY public.chemicals_container.id;


--
-- Name: chemicals_currency; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_currency (
    id bigint NOT NULL,
    name character varying(10) NOT NULL
);


ALTER TABLE public.chemicals_currency OWNER TO admin;

--
-- Name: chemicals_currency_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_currency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_currency_id_seq OWNER TO admin;

--
-- Name: chemicals_currency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_currency_id_seq OWNED BY public.chemicals_currency.id;


--
-- Name: chemicals_derivedunit; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_derivedunit (
    id bigint NOT NULL,
    exponent integer NOT NULL,
    factor double precision NOT NULL,
    si_id bigint NOT NULL,
    unit_id bigint NOT NULL
);


ALTER TABLE public.chemicals_derivedunit OWNER TO admin;

--
-- Name: chemicals_derivedunit_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_derivedunit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_derivedunit_id_seq OWNER TO admin;

--
-- Name: chemicals_derivedunit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_derivedunit_id_seq OWNED BY public.chemicals_derivedunit.id;


--
-- Name: chemicals_prefix; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_prefix (
    id bigint NOT NULL,
    name character varying(10) NOT NULL,
    symbol character varying(2) NOT NULL,
    factor double precision NOT NULL
);


ALTER TABLE public.chemicals_prefix OWNER TO admin;

--
-- Name: chemicals_prefix_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_prefix_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_prefix_id_seq OWNER TO admin;

--
-- Name: chemicals_prefix_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_prefix_id_seq OWNED BY public.chemicals_prefix.id;


--
-- Name: chemicals_si; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_si (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(10) NOT NULL
);


ALTER TABLE public.chemicals_si OWNER TO admin;

--
-- Name: chemicals_si_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_si_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_si_id_seq OWNER TO admin;

--
-- Name: chemicals_si_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_si_id_seq OWNED BY public.chemicals_si.id;


--
-- Name: chemicals_substance; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_substance (
    id bigint NOT NULL,
    names character varying(250)[] NOT NULL,
    formula character varying(100) NOT NULL,
    smiles character varying(100) NOT NULL,
    inchi character varying(100) NOT NULL,
    inchi_key character varying(100) NOT NULL,
    molecule character varying(250) NOT NULL,
    cas character varying(12) NOT NULL,
    pubchem_sid integer,
    mol_weight double precision,
    exact_mass double precision,
    color character varying(20) NOT NULL,
    melting_point double precision,
    boiling_point double precision,
    flash_point double precision,
    image character varying(100),
    boiling_point_unit_id bigint,
    exact_mass_unit_id bigint,
    flash_point_unit_id bigint,
    melting_point_unit_id bigint,
    mol_weight_unit_id bigint
);


ALTER TABLE public.chemicals_substance OWNER TO admin;

--
-- Name: chemicals_substance_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_substance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_substance_id_seq OWNER TO admin;

--
-- Name: chemicals_substance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_substance_id_seq OWNED BY public.chemicals_substance.id;


--
-- Name: chemicals_unit; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chemicals_unit (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(10) NOT NULL,
    factor double precision NOT NULL,
    type character varying(50) NOT NULL,
    prefix_id bigint
);


ALTER TABLE public.chemicals_unit OWNER TO admin;

--
-- Name: chemicals_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.chemicals_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chemicals_unit_id_seq OWNER TO admin;

--
-- Name: chemicals_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.chemicals_unit_id_seq OWNED BY public.chemicals_unit.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO admin;

--
-- Name: equipment_computer; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.equipment_computer (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    static_ip inet,
    room_id integer
);


ALTER TABLE public.equipment_computer OWNER TO admin;

--
-- Name: equipment_computer_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.equipment_computer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipment_computer_id_seq OWNER TO admin;

--
-- Name: equipment_computer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.equipment_computer_id_seq OWNED BY public.equipment_computer.id;


--
-- Name: equipment_spectrometer; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.equipment_spectrometer (
    id bigint NOT NULL,
    type character varying(10) NOT NULL,
    manufacturer character varying(50) NOT NULL,
    model character varying(100) NOT NULL,
    annotation text NOT NULL
);


ALTER TABLE public.equipment_spectrometer OWNER TO admin;

--
-- Name: equipment_spectrometer_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.equipment_spectrometer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipment_spectrometer_id_seq OWNER TO admin;

--
-- Name: equipment_spectrometer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.equipment_spectrometer_id_seq OWNED BY public.equipment_spectrometer.id;


--
-- Name: ghs_ghs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ghs_ghs (
    id bigint NOT NULL
);


ALTER TABLE public.ghs_ghs OWNER TO admin;

--
-- Name: ghs_ghs_H; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ghs_ghs_H" (
    id bigint NOT NULL,
    ghs_id bigint NOT NULL,
    hazardstatement_id bigint NOT NULL
);


ALTER TABLE public."ghs_ghs_H" OWNER TO admin;

--
-- Name: ghs_ghs_H_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."ghs_ghs_H_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ghs_ghs_H_id_seq" OWNER TO admin;

--
-- Name: ghs_ghs_H_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."ghs_ghs_H_id_seq" OWNED BY public."ghs_ghs_H".id;


--
-- Name: ghs_ghs_P; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ghs_ghs_P" (
    id bigint NOT NULL,
    ghs_id bigint NOT NULL,
    precautionarystatement_id bigint NOT NULL
);


ALTER TABLE public."ghs_ghs_P" OWNER TO admin;

--
-- Name: ghs_ghs_P_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."ghs_ghs_P_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ghs_ghs_P_id_seq" OWNER TO admin;

--
-- Name: ghs_ghs_P_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."ghs_ghs_P_id_seq" OWNED BY public."ghs_ghs_P".id;


--
-- Name: ghs_ghs_hazard_classes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ghs_ghs_hazard_classes (
    id bigint NOT NULL,
    ghs_id bigint NOT NULL,
    hazardclass_id bigint NOT NULL
);


ALTER TABLE public.ghs_ghs_hazard_classes OWNER TO admin;

--
-- Name: ghs_ghs_hazard_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ghs_ghs_hazard_classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ghs_ghs_hazard_classes_id_seq OWNER TO admin;

--
-- Name: ghs_ghs_hazard_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ghs_ghs_hazard_classes_id_seq OWNED BY public.ghs_ghs_hazard_classes.id;


--
-- Name: ghs_ghs_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ghs_ghs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ghs_ghs_id_seq OWNER TO admin;

--
-- Name: ghs_ghs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ghs_ghs_id_seq OWNED BY public.ghs_ghs.id;


--
-- Name: ghs_hazardclass; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ghs_hazardclass (
    id bigint NOT NULL,
    code character varying(2) NOT NULL,
    name character varying(20) NOT NULL,
    pictogram_id bigint
);


ALTER TABLE public.ghs_hazardclass OWNER TO admin;

--
-- Name: ghs_hazardclass_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ghs_hazardclass_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ghs_hazardclass_id_seq OWNER TO admin;

--
-- Name: ghs_hazardclass_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ghs_hazardclass_id_seq OWNED BY public.ghs_hazardclass.id;


--
-- Name: ghs_hazardstatement; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ghs_hazardstatement (
    id bigint NOT NULL,
    code character varying(5)[] NOT NULL,
    category text NOT NULL,
    statements text[] NOT NULL,
    signal_word character varying(20) NOT NULL
);


ALTER TABLE public.ghs_hazardstatement OWNER TO admin;

--
-- Name: ghs_hazardstatement_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ghs_hazardstatement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ghs_hazardstatement_id_seq OWNER TO admin;

--
-- Name: ghs_hazardstatement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ghs_hazardstatement_id_seq OWNED BY public.ghs_hazardstatement.id;


--
-- Name: ghs_pictogram; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ghs_pictogram (
    id bigint NOT NULL,
    description character varying(50) NOT NULL,
    image character varying(100)
);


ALTER TABLE public.ghs_pictogram OWNER TO admin;

--
-- Name: ghs_pictogram_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ghs_pictogram_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ghs_pictogram_id_seq OWNER TO admin;

--
-- Name: ghs_pictogram_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ghs_pictogram_id_seq OWNED BY public.ghs_pictogram.id;


--
-- Name: ghs_precautionarystatement; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ghs_precautionarystatement (
    id bigint NOT NULL,
    code character varying(3)[] NOT NULL,
    category text NOT NULL,
    statements text[] NOT NULL
);


ALTER TABLE public.ghs_precautionarystatement OWNER TO admin;

--
-- Name: ghs_precautionarystatement_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ghs_precautionarystatement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ghs_precautionarystatement_id_seq OWNER TO admin;

--
-- Name: ghs_precautionarystatement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ghs_precautionarystatement_id_seq OWNED BY public.ghs_precautionarystatement.id;


--
-- Name: locations_building; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.locations_building (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    address character varying(100) NOT NULL,
    city character varying(60) NOT NULL,
    state character varying(60) NOT NULL,
    zipcode character varying(5) NOT NULL,
    country character varying(50) NOT NULL
);


ALTER TABLE public.locations_building OWNER TO admin;

--
-- Name: locations_building_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.locations_building_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_building_id_seq OWNER TO admin;

--
-- Name: locations_building_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.locations_building_id_seq OWNED BY public.locations_building.id;


--
-- Name: locations_phonenumber; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.locations_phonenumber (
    id bigint NOT NULL,
    number character varying(128) NOT NULL,
    room_id integer NOT NULL
);


ALTER TABLE public.locations_phonenumber OWNER TO admin;

--
-- Name: locations_phonenumber_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.locations_phonenumber_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_phonenumber_id_seq OWNER TO admin;

--
-- Name: locations_phonenumber_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.locations_phonenumber_id_seq OWNED BY public.locations_phonenumber.id;


--
-- Name: locations_room; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.locations_room (
    number integer NOT NULL,
    floor integer,
    type text NOT NULL,
    building_id bigint
);


ALTER TABLE public.locations_room OWNER TO admin;

--
-- Name: locations_storage; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.locations_storage (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    compartment character varying(50) NOT NULL,
    room_id integer
);


ALTER TABLE public.locations_storage OWNER TO admin;

--
-- Name: locations_storage_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.locations_storage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_storage_id_seq OWNER TO admin;

--
-- Name: locations_storage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.locations_storage_id_seq OWNED BY public.locations_storage.id;


--
-- Name: token_blacklist_blacklistedtoken; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.token_blacklist_blacklistedtoken (
    id bigint NOT NULL,
    blacklisted_at timestamp with time zone NOT NULL,
    token_id bigint NOT NULL
);


ALTER TABLE public.token_blacklist_blacklistedtoken OWNER TO admin;

--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.token_blacklist_blacklistedtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.token_blacklist_blacklistedtoken_id_seq OWNER TO admin;

--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.token_blacklist_blacklistedtoken_id_seq OWNED BY public.token_blacklist_blacklistedtoken.id;


--
-- Name: token_blacklist_outstandingtoken; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.token_blacklist_outstandingtoken (
    id bigint NOT NULL,
    token text NOT NULL,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    user_id bigint,
    jti character varying(255) NOT NULL
);


ALTER TABLE public.token_blacklist_outstandingtoken OWNER TO admin;

--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.token_blacklist_outstandingtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.token_blacklist_outstandingtoken_id_seq OWNER TO admin;

--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.token_blacklist_outstandingtoken_id_seq OWNED BY public.token_blacklist_outstandingtoken.id;


--
-- Name: accounts_member id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member ALTER COLUMN id SET DEFAULT nextval('public.accounts_member_id_seq'::regclass);


--
-- Name: accounts_member_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_groups ALTER COLUMN id SET DEFAULT nextval('public.accounts_member_groups_id_seq'::regclass);


--
-- Name: accounts_member_phones id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_phones ALTER COLUMN id SET DEFAULT nextval('public.accounts_member_phones_id_seq'::regclass);


--
-- Name: accounts_member_role id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_role ALTER COLUMN id SET DEFAULT nextval('public.accounts_member_role_id_seq'::regclass);


--
-- Name: accounts_member_rooms id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_rooms ALTER COLUMN id SET DEFAULT nextval('public.accounts_member_rooms_id_seq'::regclass);


--
-- Name: accounts_member_user_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.accounts_member_user_permissions_id_seq'::regclass);


--
-- Name: accounts_workinggroup id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_workinggroup ALTER COLUMN id SET DEFAULT nextval('public.accounts_workinggroup_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: chemicals_category id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_category ALTER COLUMN id SET DEFAULT nextval('public.chemicals_category_id_seq'::regclass);


--
-- Name: chemicals_compound id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound ALTER COLUMN id SET DEFAULT nextval('public.chemicals_compound_id_seq'::regclass);


--
-- Name: chemicals_compound_category id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound_category ALTER COLUMN id SET DEFAULT nextval('public.chemicals_compound_category_id_seq'::regclass);


--
-- Name: chemicals_container id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container ALTER COLUMN id SET DEFAULT nextval('public.chemicals_container_id_seq'::regclass);


--
-- Name: chemicals_currency id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_currency ALTER COLUMN id SET DEFAULT nextval('public.chemicals_currency_id_seq'::regclass);


--
-- Name: chemicals_derivedunit id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_derivedunit ALTER COLUMN id SET DEFAULT nextval('public.chemicals_derivedunit_id_seq'::regclass);


--
-- Name: chemicals_prefix id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_prefix ALTER COLUMN id SET DEFAULT nextval('public.chemicals_prefix_id_seq'::regclass);


--
-- Name: chemicals_si id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_si ALTER COLUMN id SET DEFAULT nextval('public.chemicals_si_id_seq'::regclass);


--
-- Name: chemicals_substance id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_substance ALTER COLUMN id SET DEFAULT nextval('public.chemicals_substance_id_seq'::regclass);


--
-- Name: chemicals_unit id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_unit ALTER COLUMN id SET DEFAULT nextval('public.chemicals_unit_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: equipment_computer id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.equipment_computer ALTER COLUMN id SET DEFAULT nextval('public.equipment_computer_id_seq'::regclass);


--
-- Name: equipment_spectrometer id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.equipment_spectrometer ALTER COLUMN id SET DEFAULT nextval('public.equipment_spectrometer_id_seq'::regclass);


--
-- Name: ghs_ghs id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_ghs ALTER COLUMN id SET DEFAULT nextval('public.ghs_ghs_id_seq'::regclass);


--
-- Name: ghs_ghs_H id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_H" ALTER COLUMN id SET DEFAULT nextval('public."ghs_ghs_H_id_seq"'::regclass);


--
-- Name: ghs_ghs_P id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_P" ALTER COLUMN id SET DEFAULT nextval('public."ghs_ghs_P_id_seq"'::regclass);


--
-- Name: ghs_ghs_hazard_classes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_ghs_hazard_classes ALTER COLUMN id SET DEFAULT nextval('public.ghs_ghs_hazard_classes_id_seq'::regclass);


--
-- Name: ghs_hazardclass id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_hazardclass ALTER COLUMN id SET DEFAULT nextval('public.ghs_hazardclass_id_seq'::regclass);


--
-- Name: ghs_hazardstatement id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_hazardstatement ALTER COLUMN id SET DEFAULT nextval('public.ghs_hazardstatement_id_seq'::regclass);


--
-- Name: ghs_pictogram id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_pictogram ALTER COLUMN id SET DEFAULT nextval('public.ghs_pictogram_id_seq'::regclass);


--
-- Name: ghs_precautionarystatement id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_precautionarystatement ALTER COLUMN id SET DEFAULT nextval('public.ghs_precautionarystatement_id_seq'::regclass);


--
-- Name: locations_building id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_building ALTER COLUMN id SET DEFAULT nextval('public.locations_building_id_seq'::regclass);


--
-- Name: locations_phonenumber id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_phonenumber ALTER COLUMN id SET DEFAULT nextval('public.locations_phonenumber_id_seq'::regclass);


--
-- Name: locations_storage id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_storage ALTER COLUMN id SET DEFAULT nextval('public.locations_storage_id_seq'::regclass);


--
-- Name: token_blacklist_blacklistedtoken id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken ALTER COLUMN id SET DEFAULT nextval('public.token_blacklist_blacklistedtoken_id_seq'::regclass);


--
-- Name: token_blacklist_outstandingtoken id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken ALTER COLUMN id SET DEFAULT nextval('public.token_blacklist_outstandingtoken_id_seq'::regclass);


--
-- Data for Name: accounts_member; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_member (id, password, last_login, is_superuser, email, first_name, last_name, is_active, is_staff, date_joined, working_group_id) FROM stdin;
\.
COPY public.accounts_member (id, password, last_login, is_superuser, email, first_name, last_name, is_active, is_staff, date_joined, working_group_id) FROM '$$PATH$$/3282.dat';

--
-- Data for Name: accounts_member_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_member_groups (id, member_id, group_id) FROM stdin;
\.
COPY public.accounts_member_groups (id, member_id, group_id) FROM '$$PATH$$/3284.dat';

--
-- Data for Name: accounts_member_phones; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_member_phones (id, member_id, phonenumber_id) FROM stdin;
\.
COPY public.accounts_member_phones (id, member_id, phonenumber_id) FROM '$$PATH$$/3286.dat';

--
-- Data for Name: accounts_member_role; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_member_role (id, member_id, role_id) FROM stdin;
\.
COPY public.accounts_member_role (id, member_id, role_id) FROM '$$PATH$$/3288.dat';

--
-- Data for Name: accounts_member_rooms; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_member_rooms (id, member_id, room_id) FROM stdin;
\.
COPY public.accounts_member_rooms (id, member_id, room_id) FROM '$$PATH$$/3290.dat';

--
-- Data for Name: accounts_member_user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_member_user_permissions (id, member_id, permission_id) FROM stdin;
\.
COPY public.accounts_member_user_permissions (id, member_id, permission_id) FROM '$$PATH$$/3292.dat';

--
-- Data for Name: accounts_workinggroup; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_workinggroup (id, name, department, institution) FROM stdin;
\.
COPY public.accounts_workinggroup (id, name, department, institution) FROM '$$PATH$$/3280.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3278.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3274.dat';

--
-- Data for Name: chemicals_category; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_category (id, name) FROM stdin;
\.
COPY public.chemicals_category (id, name) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: chemicals_compound; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_compound (id, pubchem_cid, purity, density, created, created_by_id, density_unit_id, ghs_id, substance_id) FROM stdin;
\.
COPY public.chemicals_compound (id, pubchem_cid, purity, density, created, created_by_id, density_unit_id, ghs_id, substance_id) FROM '$$PATH$$/3314.dat';

--
-- Data for Name: chemicals_compound_category; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_compound_category (id, compound_id, category_id) FROM stdin;
\.
COPY public.chemicals_compound_category (id, compound_id, category_id) FROM '$$PATH$$/3316.dat';

--
-- Data for Name: chemicals_container; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_container (id, supplier, "EAN", product_number, amount, amount_left, tara, price, description, conditions, opened, last_used, amount_unit_id, compound_id, currency_id, last_user_id, location_id, owner_id, tara_unit_id) FROM stdin;
\.
COPY public.chemicals_container (id, supplier, "EAN", product_number, amount, amount_left, tara, price, description, conditions, opened, last_used, amount_unit_id, compound_id, currency_id, last_user_id, location_id, owner_id, tara_unit_id) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: chemicals_currency; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_currency (id, name) FROM stdin;
\.
COPY public.chemicals_currency (id, name) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: chemicals_derivedunit; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_derivedunit (id, exponent, factor, si_id, unit_id) FROM stdin;
\.
COPY public.chemicals_derivedunit (id, exponent, factor, si_id, unit_id) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: chemicals_prefix; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_prefix (id, name, symbol, factor) FROM stdin;
\.
COPY public.chemicals_prefix (id, name, symbol, factor) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: chemicals_si; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_si (id, name, symbol) FROM stdin;
\.
COPY public.chemicals_si (id, name, symbol) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: chemicals_substance; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_substance (id, names, formula, smiles, inchi, inchi_key, molecule, cas, pubchem_sid, mol_weight, exact_mass, color, melting_point, boiling_point, flash_point, image, boiling_point_unit_id, exact_mass_unit_id, flash_point_unit_id, melting_point_unit_id, mol_weight_unit_id) FROM stdin;
\.
COPY public.chemicals_substance (id, names, formula, smiles, inchi, inchi_key, molecule, cas, pubchem_sid, mol_weight, exact_mass, color, melting_point, boiling_point, flash_point, image, boiling_point_unit_id, exact_mass_unit_id, flash_point_unit_id, melting_point_unit_id, mol_weight_unit_id) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: chemicals_unit; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chemicals_unit (id, name, symbol, factor, type, prefix_id) FROM stdin;
\.
COPY public.chemicals_unit (id, name, symbol, factor, type, prefix_id) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3294.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3272.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3263.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: equipment_computer; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.equipment_computer (id, name, static_ip, room_id) FROM stdin;
\.
COPY public.equipment_computer (id, name, static_ip, room_id) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: equipment_spectrometer; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.equipment_spectrometer (id, type, manufacturer, model, annotation) FROM stdin;
\.
COPY public.equipment_spectrometer (id, type, manufacturer, model, annotation) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: ghs_ghs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ghs_ghs (id) FROM stdin;
\.
COPY public.ghs_ghs (id) FROM '$$PATH$$/3304.dat';

--
-- Data for Name: ghs_ghs_H; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."ghs_ghs_H" (id, ghs_id, hazardstatement_id) FROM stdin;
\.
COPY public."ghs_ghs_H" (id, ghs_id, hazardstatement_id) FROM '$$PATH$$/3306.dat';

--
-- Data for Name: ghs_ghs_P; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."ghs_ghs_P" (id, ghs_id, precautionarystatement_id) FROM stdin;
\.
COPY public."ghs_ghs_P" (id, ghs_id, precautionarystatement_id) FROM '$$PATH$$/3308.dat';

--
-- Data for Name: ghs_ghs_hazard_classes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ghs_ghs_hazard_classes (id, ghs_id, hazardclass_id) FROM stdin;
\.
COPY public.ghs_ghs_hazard_classes (id, ghs_id, hazardclass_id) FROM '$$PATH$$/3310.dat';

--
-- Data for Name: ghs_hazardclass; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ghs_hazardclass (id, code, name, pictogram_id) FROM stdin;
\.
COPY public.ghs_hazardclass (id, code, name, pictogram_id) FROM '$$PATH$$/3302.dat';

--
-- Data for Name: ghs_hazardstatement; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ghs_hazardstatement (id, code, category, statements, signal_word) FROM stdin;
\.
COPY public.ghs_hazardstatement (id, code, category, statements, signal_word) FROM '$$PATH$$/3296.dat';

--
-- Data for Name: ghs_pictogram; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ghs_pictogram (id, description, image) FROM stdin;
\.
COPY public.ghs_pictogram (id, description, image) FROM '$$PATH$$/3298.dat';

--
-- Data for Name: ghs_precautionarystatement; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ghs_precautionarystatement (id, code, category, statements) FROM stdin;
\.
COPY public.ghs_precautionarystatement (id, code, category, statements) FROM '$$PATH$$/3300.dat';

--
-- Data for Name: locations_building; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.locations_building (id, name, address, city, state, zipcode, country) FROM stdin;
\.
COPY public.locations_building (id, name, address, city, state, zipcode, country) FROM '$$PATH$$/3265.dat';

--
-- Data for Name: locations_phonenumber; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.locations_phonenumber (id, number, room_id) FROM stdin;
\.
COPY public.locations_phonenumber (id, number, room_id) FROM '$$PATH$$/3268.dat';

--
-- Data for Name: locations_room; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.locations_room (number, floor, type, building_id) FROM stdin;
\.
COPY public.locations_room (number, floor, type, building_id) FROM '$$PATH$$/3266.dat';

--
-- Data for Name: locations_storage; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.locations_storage (id, name, compartment, room_id) FROM stdin;
\.
COPY public.locations_storage (id, name, compartment, room_id) FROM '$$PATH$$/3270.dat';

--
-- Data for Name: token_blacklist_blacklistedtoken; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.token_blacklist_blacklistedtoken (id, blacklisted_at, token_id) FROM stdin;
\.
COPY public.token_blacklist_blacklistedtoken (id, blacklisted_at, token_id) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: token_blacklist_outstandingtoken; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.token_blacklist_outstandingtoken (id, token, created_at, expires_at, user_id, jti) FROM stdin;
\.
COPY public.token_blacklist_outstandingtoken (id, token, created_at, expires_at, user_id, jti) FROM '$$PATH$$/3337.dat';

--
-- Name: accounts_member_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_member_groups_id_seq', 1, false);


--
-- Name: accounts_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_member_id_seq', 1, true);


--
-- Name: accounts_member_phones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_member_phones_id_seq', 1, true);


--
-- Name: accounts_member_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_member_role_id_seq', 1, true);


--
-- Name: accounts_member_rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_member_rooms_id_seq', 1, true);


--
-- Name: accounts_member_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_member_user_permissions_id_seq', 1, false);


--
-- Name: accounts_workinggroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_workinggroup_id_seq', 1, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 5, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 120, true);


--
-- Name: chemicals_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_category_id_seq', 1, true);


--
-- Name: chemicals_compound_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_compound_category_id_seq', 1, true);


--
-- Name: chemicals_compound_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_compound_id_seq', 1, true);


--
-- Name: chemicals_container_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_container_id_seq', 1, true);


--
-- Name: chemicals_currency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_currency_id_seq', 1, true);


--
-- Name: chemicals_derivedunit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_derivedunit_id_seq', 1, false);


--
-- Name: chemicals_prefix_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_prefix_id_seq', 1, true);


--
-- Name: chemicals_si_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_si_id_seq', 2, true);


--
-- Name: chemicals_substance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_substance_id_seq', 1, true);


--
-- Name: chemicals_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.chemicals_unit_id_seq', 5, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 47, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 30, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 34, true);


--
-- Name: equipment_computer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.equipment_computer_id_seq', 1, false);


--
-- Name: equipment_spectrometer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.equipment_spectrometer_id_seq', 1, false);


--
-- Name: ghs_ghs_H_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."ghs_ghs_H_id_seq"', 2, true);


--
-- Name: ghs_ghs_P_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."ghs_ghs_P_id_seq"', 2, true);


--
-- Name: ghs_ghs_hazard_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ghs_ghs_hazard_classes_id_seq', 2, true);


--
-- Name: ghs_ghs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ghs_ghs_id_seq', 1, true);


--
-- Name: ghs_hazardclass_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ghs_hazardclass_id_seq', 2, true);


--
-- Name: ghs_hazardstatement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ghs_hazardstatement_id_seq', 3, true);


--
-- Name: ghs_pictogram_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ghs_pictogram_id_seq', 2, true);


--
-- Name: ghs_precautionarystatement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ghs_precautionarystatement_id_seq', 2, true);


--
-- Name: locations_building_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.locations_building_id_seq', 1, true);


--
-- Name: locations_phonenumber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.locations_phonenumber_id_seq', 1, true);


--
-- Name: locations_storage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.locations_storage_id_seq', 1, true);


--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.token_blacklist_blacklistedtoken_id_seq', 17, true);


--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.token_blacklist_outstandingtoken_id_seq', 23, true);


--
-- Name: accounts_member accounts_member_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member
    ADD CONSTRAINT accounts_member_email_key UNIQUE (email);


--
-- Name: accounts_member_groups accounts_member_groups_member_id_group_id_c77bff9c_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_groups
    ADD CONSTRAINT accounts_member_groups_member_id_group_id_c77bff9c_uniq UNIQUE (member_id, group_id);


--
-- Name: accounts_member_groups accounts_member_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_groups
    ADD CONSTRAINT accounts_member_groups_pkey PRIMARY KEY (id);


--
-- Name: accounts_member_phones accounts_member_phones_member_id_phonenumber_id_626f9f84_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_phones
    ADD CONSTRAINT accounts_member_phones_member_id_phonenumber_id_626f9f84_uniq UNIQUE (member_id, phonenumber_id);


--
-- Name: accounts_member_phones accounts_member_phones_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_phones
    ADD CONSTRAINT accounts_member_phones_pkey PRIMARY KEY (id);


--
-- Name: accounts_member accounts_member_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member
    ADD CONSTRAINT accounts_member_pkey PRIMARY KEY (id);


--
-- Name: accounts_member_role accounts_member_role_member_id_role_id_6fc3ef28_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_role
    ADD CONSTRAINT accounts_member_role_member_id_role_id_6fc3ef28_uniq UNIQUE (member_id, role_id);


--
-- Name: accounts_member_role accounts_member_role_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_role
    ADD CONSTRAINT accounts_member_role_pkey PRIMARY KEY (id);


--
-- Name: accounts_member_rooms accounts_member_rooms_member_id_room_id_b17e58c1_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_rooms
    ADD CONSTRAINT accounts_member_rooms_member_id_room_id_b17e58c1_uniq UNIQUE (member_id, room_id);


--
-- Name: accounts_member_rooms accounts_member_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_rooms
    ADD CONSTRAINT accounts_member_rooms_pkey PRIMARY KEY (id);


--
-- Name: accounts_member_user_permissions accounts_member_user_per_member_id_permission_id_0ae3c3ea_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_user_permissions
    ADD CONSTRAINT accounts_member_user_per_member_id_permission_id_0ae3c3ea_uniq UNIQUE (member_id, permission_id);


--
-- Name: accounts_member_user_permissions accounts_member_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_user_permissions
    ADD CONSTRAINT accounts_member_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: accounts_workinggroup accounts_workinggroup_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_workinggroup
    ADD CONSTRAINT accounts_workinggroup_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: chemicals_category chemicals_category_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_category
    ADD CONSTRAINT chemicals_category_pkey PRIMARY KEY (id);


--
-- Name: chemicals_compound_category chemicals_compound_categ_compound_id_category_id_a63f5604_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound_category
    ADD CONSTRAINT chemicals_compound_categ_compound_id_category_id_a63f5604_uniq UNIQUE (compound_id, category_id);


--
-- Name: chemicals_compound_category chemicals_compound_category_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound_category
    ADD CONSTRAINT chemicals_compound_category_pkey PRIMARY KEY (id);


--
-- Name: chemicals_compound chemicals_compound_ghs_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound
    ADD CONSTRAINT chemicals_compound_ghs_id_key UNIQUE (ghs_id);


--
-- Name: chemicals_compound chemicals_compound_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound
    ADD CONSTRAINT chemicals_compound_pkey PRIMARY KEY (id);


--
-- Name: chemicals_container chemicals_container_last_user_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_last_user_id_key UNIQUE (last_user_id);


--
-- Name: chemicals_container chemicals_container_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_pkey PRIMARY KEY (id);


--
-- Name: chemicals_currency chemicals_currency_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_currency
    ADD CONSTRAINT chemicals_currency_name_key UNIQUE (name);


--
-- Name: chemicals_currency chemicals_currency_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_currency
    ADD CONSTRAINT chemicals_currency_pkey PRIMARY KEY (id);


--
-- Name: chemicals_derivedunit chemicals_derivedunit_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_derivedunit
    ADD CONSTRAINT chemicals_derivedunit_pkey PRIMARY KEY (id);


--
-- Name: chemicals_prefix chemicals_prefix_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_prefix
    ADD CONSTRAINT chemicals_prefix_pkey PRIMARY KEY (id);


--
-- Name: chemicals_prefix chemicals_prefix_symbol_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_prefix
    ADD CONSTRAINT chemicals_prefix_symbol_key UNIQUE (symbol);


--
-- Name: chemicals_si chemicals_si_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_si
    ADD CONSTRAINT chemicals_si_pkey PRIMARY KEY (id);


--
-- Name: chemicals_si chemicals_si_symbol_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_si
    ADD CONSTRAINT chemicals_si_symbol_key UNIQUE (symbol);


--
-- Name: chemicals_substance chemicals_substance_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_substance
    ADD CONSTRAINT chemicals_substance_pkey PRIMARY KEY (id);


--
-- Name: chemicals_unit chemicals_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_unit
    ADD CONSTRAINT chemicals_unit_pkey PRIMARY KEY (id);


--
-- Name: chemicals_unit chemicals_unit_prefix_id_symbol_ec9371fb_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_unit
    ADD CONSTRAINT chemicals_unit_prefix_id_symbol_ec9371fb_uniq UNIQUE (prefix_id, symbol);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: equipment_computer equipment_computer_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.equipment_computer
    ADD CONSTRAINT equipment_computer_pkey PRIMARY KEY (id);


--
-- Name: equipment_spectrometer equipment_spectrometer_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.equipment_spectrometer
    ADD CONSTRAINT equipment_spectrometer_pkey PRIMARY KEY (id);


--
-- Name: ghs_ghs_H ghs_ghs_H_ghs_id_hazardstatement_id_def07d71_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_H"
    ADD CONSTRAINT "ghs_ghs_H_ghs_id_hazardstatement_id_def07d71_uniq" UNIQUE (ghs_id, hazardstatement_id);


--
-- Name: ghs_ghs_H ghs_ghs_H_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_H"
    ADD CONSTRAINT "ghs_ghs_H_pkey" PRIMARY KEY (id);


--
-- Name: ghs_ghs_P ghs_ghs_P_ghs_id_precautionarystatement_id_da936c11_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_P"
    ADD CONSTRAINT "ghs_ghs_P_ghs_id_precautionarystatement_id_da936c11_uniq" UNIQUE (ghs_id, precautionarystatement_id);


--
-- Name: ghs_ghs_P ghs_ghs_P_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_P"
    ADD CONSTRAINT "ghs_ghs_P_pkey" PRIMARY KEY (id);


--
-- Name: ghs_ghs_hazard_classes ghs_ghs_hazard_classes_ghs_id_hazardclass_id_c7c34cd5_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_ghs_hazard_classes
    ADD CONSTRAINT ghs_ghs_hazard_classes_ghs_id_hazardclass_id_c7c34cd5_uniq UNIQUE (ghs_id, hazardclass_id);


--
-- Name: ghs_ghs_hazard_classes ghs_ghs_hazard_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_ghs_hazard_classes
    ADD CONSTRAINT ghs_ghs_hazard_classes_pkey PRIMARY KEY (id);


--
-- Name: ghs_ghs ghs_ghs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_ghs
    ADD CONSTRAINT ghs_ghs_pkey PRIMARY KEY (id);


--
-- Name: ghs_hazardclass ghs_hazardclass_code_name_450b9a61_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_hazardclass
    ADD CONSTRAINT ghs_hazardclass_code_name_450b9a61_uniq UNIQUE (code, name);


--
-- Name: ghs_hazardclass ghs_hazardclass_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_hazardclass
    ADD CONSTRAINT ghs_hazardclass_pkey PRIMARY KEY (id);


--
-- Name: ghs_hazardstatement ghs_hazardstatement_code_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_hazardstatement
    ADD CONSTRAINT ghs_hazardstatement_code_key UNIQUE (code);


--
-- Name: ghs_hazardstatement ghs_hazardstatement_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_hazardstatement
    ADD CONSTRAINT ghs_hazardstatement_pkey PRIMARY KEY (id);


--
-- Name: ghs_pictogram ghs_pictogram_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_pictogram
    ADD CONSTRAINT ghs_pictogram_pkey PRIMARY KEY (id);


--
-- Name: ghs_precautionarystatement ghs_precautionarystatement_code_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_precautionarystatement
    ADD CONSTRAINT ghs_precautionarystatement_code_key UNIQUE (code);


--
-- Name: ghs_precautionarystatement ghs_precautionarystatement_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_precautionarystatement
    ADD CONSTRAINT ghs_precautionarystatement_pkey PRIMARY KEY (id);


--
-- Name: locations_building locations_building_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_building
    ADD CONSTRAINT locations_building_name_key UNIQUE (name);


--
-- Name: locations_building locations_building_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_building
    ADD CONSTRAINT locations_building_pkey PRIMARY KEY (id);


--
-- Name: locations_phonenumber locations_phonenumber_number_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_phonenumber
    ADD CONSTRAINT locations_phonenumber_number_key UNIQUE (number);


--
-- Name: locations_phonenumber locations_phonenumber_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_phonenumber
    ADD CONSTRAINT locations_phonenumber_pkey PRIMARY KEY (id);


--
-- Name: locations_room locations_room_number_floor_building_id_8afd92f8_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_room
    ADD CONSTRAINT locations_room_number_floor_building_id_8afd92f8_uniq UNIQUE (number, floor, building_id);


--
-- Name: locations_room locations_room_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_room
    ADD CONSTRAINT locations_room_pkey PRIMARY KEY (number);


--
-- Name: locations_storage locations_storage_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_storage
    ADD CONSTRAINT locations_storage_pkey PRIMARY KEY (id);


--
-- Name: locations_storage locations_storage_room_id_name_compartment_01930274_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_storage
    ADD CONSTRAINT locations_storage_room_id_name_compartment_01930274_uniq UNIQUE (room_id, name, compartment);


--
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_pkey PRIMARY KEY (id);


--
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_token_id_key UNIQUE (token_id);


--
-- Name: token_blacklist_outstandingtoken token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq UNIQUE (jti);


--
-- Name: token_blacklist_outstandingtoken token_blacklist_outstandingtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outstandingtoken_pkey PRIMARY KEY (id);


--
-- Name: accounts_member_email_c12225e9_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_email_c12225e9_like ON public.accounts_member USING btree (email varchar_pattern_ops);


--
-- Name: accounts_member_groups_group_id_5c4b2fbe; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_groups_group_id_5c4b2fbe ON public.accounts_member_groups USING btree (group_id);


--
-- Name: accounts_member_groups_member_id_e68138f6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_groups_member_id_e68138f6 ON public.accounts_member_groups USING btree (member_id);


--
-- Name: accounts_member_phones_member_id_2af9f4a3; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_phones_member_id_2af9f4a3 ON public.accounts_member_phones USING btree (member_id);


--
-- Name: accounts_member_phones_phonenumber_id_2318f215; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_phones_phonenumber_id_2318f215 ON public.accounts_member_phones USING btree (phonenumber_id);


--
-- Name: accounts_member_role_member_id_9260b534; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_role_member_id_9260b534 ON public.accounts_member_role USING btree (member_id);


--
-- Name: accounts_member_role_role_id_651329b1; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_role_role_id_651329b1 ON public.accounts_member_role USING btree (role_id);


--
-- Name: accounts_member_rooms_member_id_6da8cc7f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_rooms_member_id_6da8cc7f ON public.accounts_member_rooms USING btree (member_id);


--
-- Name: accounts_member_rooms_room_id_aa2241ba; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_rooms_room_id_aa2241ba ON public.accounts_member_rooms USING btree (room_id);


--
-- Name: accounts_member_user_permissions_member_id_dded25fd; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_user_permissions_member_id_dded25fd ON public.accounts_member_user_permissions USING btree (member_id);


--
-- Name: accounts_member_user_permissions_permission_id_1dd5f43a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_user_permissions_permission_id_1dd5f43a ON public.accounts_member_user_permissions USING btree (permission_id);


--
-- Name: accounts_member_working_group_id_63e8551e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX accounts_member_working_group_id_63e8551e ON public.accounts_member USING btree (working_group_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: chemicals_compound_category_category_id_c7f111ad; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_compound_category_category_id_c7f111ad ON public.chemicals_compound_category USING btree (category_id);


--
-- Name: chemicals_compound_category_compound_id_5ca825eb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_compound_category_compound_id_5ca825eb ON public.chemicals_compound_category USING btree (compound_id);


--
-- Name: chemicals_compound_created_by_id_e032dfa9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_compound_created_by_id_e032dfa9 ON public.chemicals_compound USING btree (created_by_id);


--
-- Name: chemicals_compound_density_unit_id_5b302924; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_compound_density_unit_id_5b302924 ON public.chemicals_compound USING btree (density_unit_id);


--
-- Name: chemicals_compound_substance_id_1d0161be; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_compound_substance_id_1d0161be ON public.chemicals_compound USING btree (substance_id);


--
-- Name: chemicals_container_amount_unit_id_0e2242bd; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_container_amount_unit_id_0e2242bd ON public.chemicals_container USING btree (amount_unit_id);


--
-- Name: chemicals_container_compound_id_99f8560d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_container_compound_id_99f8560d ON public.chemicals_container USING btree (compound_id);


--
-- Name: chemicals_container_currency_id_42001710; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_container_currency_id_42001710 ON public.chemicals_container USING btree (currency_id);


--
-- Name: chemicals_container_location_id_9c2ceaa7; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_container_location_id_9c2ceaa7 ON public.chemicals_container USING btree (location_id);


--
-- Name: chemicals_container_owner_id_a17eea36; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_container_owner_id_a17eea36 ON public.chemicals_container USING btree (owner_id);


--
-- Name: chemicals_container_tara_unit_id_b2a66945; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_container_tara_unit_id_b2a66945 ON public.chemicals_container USING btree (tara_unit_id);


--
-- Name: chemicals_currency_name_920abca9_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_currency_name_920abca9_like ON public.chemicals_currency USING btree (name varchar_pattern_ops);


--
-- Name: chemicals_derivedunit_si_id_41e3fc5d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_derivedunit_si_id_41e3fc5d ON public.chemicals_derivedunit USING btree (si_id);


--
-- Name: chemicals_derivedunit_unit_id_a5b555ee; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_derivedunit_unit_id_a5b555ee ON public.chemicals_derivedunit USING btree (unit_id);


--
-- Name: chemicals_prefix_symbol_6a384fac_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_prefix_symbol_6a384fac_like ON public.chemicals_prefix USING btree (symbol varchar_pattern_ops);


--
-- Name: chemicals_si_symbol_c2dd81b9_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_si_symbol_c2dd81b9_like ON public.chemicals_si USING btree (symbol varchar_pattern_ops);


--
-- Name: chemicals_substance_boiling_point_unit_id_5f64d77e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_substance_boiling_point_unit_id_5f64d77e ON public.chemicals_substance USING btree (boiling_point_unit_id);


--
-- Name: chemicals_substance_exact_mass_unit_id_72c10681; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_substance_exact_mass_unit_id_72c10681 ON public.chemicals_substance USING btree (exact_mass_unit_id);


--
-- Name: chemicals_substance_flash_point_unit_id_434821e6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_substance_flash_point_unit_id_434821e6 ON public.chemicals_substance USING btree (flash_point_unit_id);


--
-- Name: chemicals_substance_melting_point_unit_id_f091af57; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_substance_melting_point_unit_id_f091af57 ON public.chemicals_substance USING btree (melting_point_unit_id);


--
-- Name: chemicals_substance_mol_weight_unit_id_743baa5a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_substance_mol_weight_unit_id_743baa5a ON public.chemicals_substance USING btree (mol_weight_unit_id);


--
-- Name: chemicals_unit_prefix_id_a8f5be54; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX chemicals_unit_prefix_id_a8f5be54 ON public.chemicals_unit USING btree (prefix_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: equipment_computer_room_id_aec272f4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX equipment_computer_room_id_aec272f4 ON public.equipment_computer USING btree (room_id);


--
-- Name: ghs_ghs_H_ghs_id_e39ef3ab; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "ghs_ghs_H_ghs_id_e39ef3ab" ON public."ghs_ghs_H" USING btree (ghs_id);


--
-- Name: ghs_ghs_H_hazardstatement_id_d5b252ae; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "ghs_ghs_H_hazardstatement_id_d5b252ae" ON public."ghs_ghs_H" USING btree (hazardstatement_id);


--
-- Name: ghs_ghs_P_ghs_id_6a148569; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "ghs_ghs_P_ghs_id_6a148569" ON public."ghs_ghs_P" USING btree (ghs_id);


--
-- Name: ghs_ghs_P_precautionarystatement_id_d8e0b2e3; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "ghs_ghs_P_precautionarystatement_id_d8e0b2e3" ON public."ghs_ghs_P" USING btree (precautionarystatement_id);


--
-- Name: ghs_ghs_hazard_classes_ghs_id_bcaa6a78; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ghs_ghs_hazard_classes_ghs_id_bcaa6a78 ON public.ghs_ghs_hazard_classes USING btree (ghs_id);


--
-- Name: ghs_ghs_hazard_classes_hazardclass_id_a95e5513; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ghs_ghs_hazard_classes_hazardclass_id_a95e5513 ON public.ghs_ghs_hazard_classes USING btree (hazardclass_id);


--
-- Name: ghs_hazardclass_pictogram_id_c4e68209; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ghs_hazardclass_pictogram_id_c4e68209 ON public.ghs_hazardclass USING btree (pictogram_id);


--
-- Name: locations_building_name_bb01fc2f_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX locations_building_name_bb01fc2f_like ON public.locations_building USING btree (name varchar_pattern_ops);


--
-- Name: locations_phonenumber_number_1ca53d05_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX locations_phonenumber_number_1ca53d05_like ON public.locations_phonenumber USING btree (number varchar_pattern_ops);


--
-- Name: locations_phonenumber_room_id_1bae516c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX locations_phonenumber_room_id_1bae516c ON public.locations_phonenumber USING btree (room_id);


--
-- Name: locations_room_building_id_c1b2fd77; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX locations_room_building_id_c1b2fd77 ON public.locations_room USING btree (building_id);


--
-- Name: locations_storage_room_id_c8f3c763; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX locations_storage_room_id_c8f3c763 ON public.locations_storage USING btree (room_id);


--
-- Name: token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_like ON public.token_blacklist_outstandingtoken USING btree (jti varchar_pattern_ops);


--
-- Name: token_blacklist_outstandingtoken_user_id_83bc629a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX token_blacklist_outstandingtoken_user_id_83bc629a ON public.token_blacklist_outstandingtoken USING btree (user_id);


--
-- Name: accounts_member_groups accounts_member_groups_group_id_5c4b2fbe_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_groups
    ADD CONSTRAINT accounts_member_groups_group_id_5c4b2fbe_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_groups accounts_member_groups_member_id_e68138f6_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_groups
    ADD CONSTRAINT accounts_member_groups_member_id_e68138f6_fk_accounts_member_id FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_phones accounts_member_phon_phonenumber_id_2318f215_fk_locations; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_phones
    ADD CONSTRAINT accounts_member_phon_phonenumber_id_2318f215_fk_locations FOREIGN KEY (phonenumber_id) REFERENCES public.locations_phonenumber(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_phones accounts_member_phones_member_id_2af9f4a3_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_phones
    ADD CONSTRAINT accounts_member_phones_member_id_2af9f4a3_fk_accounts_member_id FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_role accounts_member_role_member_id_9260b534_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_role
    ADD CONSTRAINT accounts_member_role_member_id_9260b534_fk_accounts_member_id FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_role accounts_member_role_role_id_651329b1_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_role
    ADD CONSTRAINT accounts_member_role_role_id_651329b1_fk_auth_group_id FOREIGN KEY (role_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_rooms accounts_member_rooms_member_id_6da8cc7f_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_rooms
    ADD CONSTRAINT accounts_member_rooms_member_id_6da8cc7f_fk_accounts_member_id FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_rooms accounts_member_rooms_room_id_aa2241ba_fk_locations_room_number; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_rooms
    ADD CONSTRAINT accounts_member_rooms_room_id_aa2241ba_fk_locations_room_number FOREIGN KEY (room_id) REFERENCES public.locations_room(number) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_user_permissions accounts_member_user_member_id_dded25fd_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_user_permissions
    ADD CONSTRAINT accounts_member_user_member_id_dded25fd_fk_accounts_ FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member_user_permissions accounts_member_user_permission_id_1dd5f43a_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member_user_permissions
    ADD CONSTRAINT accounts_member_user_permission_id_1dd5f43a_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_member accounts_member_working_group_id_63e8551e_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_member
    ADD CONSTRAINT accounts_member_working_group_id_63e8551e_fk_accounts_ FOREIGN KEY (working_group_id) REFERENCES public.accounts_workinggroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_compound_category chemicals_compound_c_category_id_c7f111ad_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound_category
    ADD CONSTRAINT chemicals_compound_c_category_id_c7f111ad_fk_chemicals FOREIGN KEY (category_id) REFERENCES public.chemicals_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_compound_category chemicals_compound_c_compound_id_5ca825eb_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound_category
    ADD CONSTRAINT chemicals_compound_c_compound_id_5ca825eb_fk_chemicals FOREIGN KEY (compound_id) REFERENCES public.chemicals_compound(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_compound chemicals_compound_created_by_id_e032dfa9_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound
    ADD CONSTRAINT chemicals_compound_created_by_id_e032dfa9_fk_accounts_member_id FOREIGN KEY (created_by_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_compound chemicals_compound_density_unit_id_5b302924_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound
    ADD CONSTRAINT chemicals_compound_density_unit_id_5b302924_fk_chemicals FOREIGN KEY (density_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_compound chemicals_compound_ghs_id_dcc2f858_fk_ghs_ghs_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound
    ADD CONSTRAINT chemicals_compound_ghs_id_dcc2f858_fk_ghs_ghs_id FOREIGN KEY (ghs_id) REFERENCES public.ghs_ghs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_compound chemicals_compound_substance_id_1d0161be_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_compound
    ADD CONSTRAINT chemicals_compound_substance_id_1d0161be_fk_chemicals FOREIGN KEY (substance_id) REFERENCES public.chemicals_substance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_container chemicals_container_amount_unit_id_0e2242bd_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_amount_unit_id_0e2242bd_fk_chemicals FOREIGN KEY (amount_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_container chemicals_container_compound_id_99f8560d_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_compound_id_99f8560d_fk_chemicals FOREIGN KEY (compound_id) REFERENCES public.chemicals_compound(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_container chemicals_container_currency_id_42001710_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_currency_id_42001710_fk_chemicals FOREIGN KEY (currency_id) REFERENCES public.chemicals_currency(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_container chemicals_container_last_user_id_3bd8a30b_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_last_user_id_3bd8a30b_fk_accounts_member_id FOREIGN KEY (last_user_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_container chemicals_container_location_id_9c2ceaa7_fk_locations; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_location_id_9c2ceaa7_fk_locations FOREIGN KEY (location_id) REFERENCES public.locations_storage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_container chemicals_container_owner_id_a17eea36_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_owner_id_a17eea36_fk_accounts_ FOREIGN KEY (owner_id) REFERENCES public.accounts_workinggroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_container chemicals_container_tara_unit_id_b2a66945_fk_chemicals_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_container
    ADD CONSTRAINT chemicals_container_tara_unit_id_b2a66945_fk_chemicals_unit_id FOREIGN KEY (tara_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_derivedunit chemicals_derivedunit_si_id_41e3fc5d_fk_chemicals_si_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_derivedunit
    ADD CONSTRAINT chemicals_derivedunit_si_id_41e3fc5d_fk_chemicals_si_id FOREIGN KEY (si_id) REFERENCES public.chemicals_si(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_derivedunit chemicals_derivedunit_unit_id_a5b555ee_fk_chemicals_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_derivedunit
    ADD CONSTRAINT chemicals_derivedunit_unit_id_a5b555ee_fk_chemicals_unit_id FOREIGN KEY (unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_substance chemicals_substance_boiling_point_unit_i_5f64d77e_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_substance
    ADD CONSTRAINT chemicals_substance_boiling_point_unit_i_5f64d77e_fk_chemicals FOREIGN KEY (boiling_point_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_substance chemicals_substance_exact_mass_unit_id_72c10681_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_substance
    ADD CONSTRAINT chemicals_substance_exact_mass_unit_id_72c10681_fk_chemicals FOREIGN KEY (exact_mass_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_substance chemicals_substance_flash_point_unit_id_434821e6_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_substance
    ADD CONSTRAINT chemicals_substance_flash_point_unit_id_434821e6_fk_chemicals FOREIGN KEY (flash_point_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_substance chemicals_substance_melting_point_unit_i_f091af57_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_substance
    ADD CONSTRAINT chemicals_substance_melting_point_unit_i_f091af57_fk_chemicals FOREIGN KEY (melting_point_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_substance chemicals_substance_mol_weight_unit_id_743baa5a_fk_chemicals; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_substance
    ADD CONSTRAINT chemicals_substance_mol_weight_unit_id_743baa5a_fk_chemicals FOREIGN KEY (mol_weight_unit_id) REFERENCES public.chemicals_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chemicals_unit chemicals_unit_prefix_id_a8f5be54_fk_chemicals_prefix_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chemicals_unit
    ADD CONSTRAINT chemicals_unit_prefix_id_a8f5be54_fk_chemicals_prefix_id FOREIGN KEY (prefix_id) REFERENCES public.chemicals_prefix(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_accounts_member_id FOREIGN KEY (user_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: equipment_computer equipment_computer_room_id_aec272f4_fk_locations_room_number; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.equipment_computer
    ADD CONSTRAINT equipment_computer_room_id_aec272f4_fk_locations_room_number FOREIGN KEY (room_id) REFERENCES public.locations_room(number) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ghs_ghs_H ghs_ghs_H_ghs_id_e39ef3ab_fk_ghs_ghs_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_H"
    ADD CONSTRAINT "ghs_ghs_H_ghs_id_e39ef3ab_fk_ghs_ghs_id" FOREIGN KEY (ghs_id) REFERENCES public.ghs_ghs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ghs_ghs_H ghs_ghs_H_hazardstatement_id_d5b252ae_fk_ghs_hazardstatement_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_H"
    ADD CONSTRAINT "ghs_ghs_H_hazardstatement_id_d5b252ae_fk_ghs_hazardstatement_id" FOREIGN KEY (hazardstatement_id) REFERENCES public.ghs_hazardstatement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ghs_ghs_P ghs_ghs_P_ghs_id_6a148569_fk_ghs_ghs_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_P"
    ADD CONSTRAINT "ghs_ghs_P_ghs_id_6a148569_fk_ghs_ghs_id" FOREIGN KEY (ghs_id) REFERENCES public.ghs_ghs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ghs_ghs_P ghs_ghs_P_precautionarystateme_d8e0b2e3_fk_ghs_preca; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ghs_ghs_P"
    ADD CONSTRAINT "ghs_ghs_P_precautionarystateme_d8e0b2e3_fk_ghs_preca" FOREIGN KEY (precautionarystatement_id) REFERENCES public.ghs_precautionarystatement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ghs_ghs_hazard_classes ghs_ghs_hazard_class_hazardclass_id_a95e5513_fk_ghs_hazar; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_ghs_hazard_classes
    ADD CONSTRAINT ghs_ghs_hazard_class_hazardclass_id_a95e5513_fk_ghs_hazar FOREIGN KEY (hazardclass_id) REFERENCES public.ghs_hazardclass(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ghs_ghs_hazard_classes ghs_ghs_hazard_classes_ghs_id_bcaa6a78_fk_ghs_ghs_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_ghs_hazard_classes
    ADD CONSTRAINT ghs_ghs_hazard_classes_ghs_id_bcaa6a78_fk_ghs_ghs_id FOREIGN KEY (ghs_id) REFERENCES public.ghs_ghs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ghs_hazardclass ghs_hazardclass_pictogram_id_c4e68209_fk_ghs_pictogram_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ghs_hazardclass
    ADD CONSTRAINT ghs_hazardclass_pictogram_id_c4e68209_fk_ghs_pictogram_id FOREIGN KEY (pictogram_id) REFERENCES public.ghs_pictogram(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locations_phonenumber locations_phonenumber_room_id_1bae516c_fk_locations_room_number; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_phonenumber
    ADD CONSTRAINT locations_phonenumber_room_id_1bae516c_fk_locations_room_number FOREIGN KEY (room_id) REFERENCES public.locations_room(number) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locations_room locations_room_building_id_c1b2fd77_fk_locations_building_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_room
    ADD CONSTRAINT locations_room_building_id_c1b2fd77_fk_locations_building_id FOREIGN KEY (building_id) REFERENCES public.locations_building(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locations_storage locations_storage_room_id_c8f3c763_fk_locations_room_number; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.locations_storage
    ADD CONSTRAINT locations_storage_room_id_c8f3c763_fk_locations_room_number FOREIGN KEY (room_id) REFERENCES public.locations_room(number) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk FOREIGN KEY (token_id) REFERENCES public.token_blacklist_outstandingtoken(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: token_blacklist_outstandingtoken token_blacklist_outs_user_id_83bc629a_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outs_user_id_83bc629a_fk_accounts_ FOREIGN KEY (user_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

